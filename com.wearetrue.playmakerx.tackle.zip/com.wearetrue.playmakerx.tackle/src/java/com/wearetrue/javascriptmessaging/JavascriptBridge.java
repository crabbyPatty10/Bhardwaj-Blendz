package com.wearetrue.javascriptmessaging;

import android.util.Log;
import kotlin.jvm.internal.TypeIntrinsics;
import java.util.Iterator;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;
import java.util.List;
import android.webkit.ValueCallback;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import java.util.HashMap;
import kotlin.Metadata;

@Metadata(bv = { 1, 0, 3 }, d1 = { "\u0000`\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0010\u0018\u00002\u00020\u0001BL\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012'\b\u0002\u0010\u0006\u001a!\u0012\u0013\u0012\u00110\b¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f\u0018\u00010\u0007\u0012\b\b\u0002\u0010\r\u001a\u00020\u000e¢\u0006\u0002\u0010\u000fJG\u0010\"\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u00052\n\b\u0002\u0010#\u001a\u0004\u0018\u00010\f2+\b\u0002\u0010$\u001a%\u0012\u0013\u0012\u00110\b¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\u000b\u0012\u0004\u0012\u00020\u0012\u0018\u00010\u0007j\u0004\u0018\u0001`\u0013J\u0010\u0010%\u001a\u00020\u00122\u0006\u0010&\u001a\u00020\u0005H\u0016J\u0010\u0010'\u001a\u00020\u00122\u0006\u0010\u000b\u001a\u00020\bH\u0002J\b\u0010(\u001a\u00020\u0012H\u0002J\u0010\u0010)\u001a\u00020\u00122\u0006\u0010\u000b\u001a\u00020\bH\u0002J\u000e\u0010*\u001a\u00020\u00122\u0006\u0010+\u001a\u00020\u0005J\u000e\u0010,\u001a\u00020\u00122\u0006\u0010\u000b\u001a\u00020\bJG\u0010,\u001a\u00020\u00122\u0006\u0010\n\u001a\u00020\u00052\n\b\u0002\u0010#\u001a\u0004\u0018\u00010\f2+\b\u0002\u0010$\u001a%\u0012\u0013\u0012\u00110\b¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\u000b\u0012\u0004\u0012\u00020\u0012\u0018\u00010\u0007j\u0004\u0018\u0001`\u0013J\u001c\u0010-\u001a\u00020\u00122\u0006\u0010+\u001a\u00020\u00052\f\u0010.\u001a\b\u0012\u0004\u0012\u00020\b0\u0016R9\u0010\u0010\u001a-\u0012\u0004\u0012\u00020\u0005\u0012#\u0012!\u0012\u0013\u0012\u00110\b¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\u000b\u0012\u0004\u0012\u00020\u00120\u0007j\u0002`\u00130\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u0015\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00160\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0017\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0019\u001a\u00020\u001a@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b \u0010!¨\u0006/" }, d2 = { "Lcom/wearetrue/javascriptmessaging/JavascriptBridge;", "Lcom/wearetrue/javascriptmessaging/JavascriptMessageReceiver;", "webviewMessageInterface", "Lcom/wearetrue/javascriptmessaging/WebviewMessageInterface;", "initMessageName", "", "initMessageProcessor", "Lkotlin/Function1;", "Lcom/wearetrue/javascriptmessaging/JavascriptMessage;", "Lkotlin/ParameterName;", "name", "message", "Lorg/json/JSONObject;", "propertyMap", "Lcom/wearetrue/javascriptmessaging/MessagePropertyMap;", "(Lcom/wearetrue/javascriptmessaging/WebviewMessageInterface;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lcom/wearetrue/javascriptmessaging/MessagePropertyMap;)V", "_callbackHandlers", "Ljava/util/HashMap;", "", "Lcom/wearetrue/javascriptmessaging/JavascriptMessageHandler;", "_initMessageName", "_messageHandlers", "Landroid/webkit/ValueCallback;", "_pendingMessages", "", "<set-?>", "", "initialized", "getInitialized", "()Z", "messageCount", "", "getWebviewMessageInterface", "()Lcom/wearetrue/javascriptmessaging/WebviewMessageInterface;", "createMessage", "payload", "callback", "didReceiveMessage", "json", "dispatchMessage", "flushPending", "queueMessage", "removeHandler", "messageName", "sendMessage", "setHandler", "handler", "JavascriptMessaging_release" }, k = 1, mv = { 1, 4, 2 })
public final class JavascriptBridge implements JavascriptMessageReceiver
{
    private final HashMap<String, Function1<JavascriptMessage, Unit>> _callbackHandlers;
    private final String _initMessageName;
    private final HashMap<String, ValueCallback<JavascriptMessage>> _messageHandlers;
    private List<JavascriptMessage> _pendingMessages;
    private boolean initialized;
    private int messageCount;
    private final MessagePropertyMap propertyMap;
    private final WebviewMessageInterface webviewMessageInterface;
    
    public JavascriptBridge(final WebviewMessageInterface webviewMessageInterface, String format, final Function1<? super JavascriptMessage, ? extends JSONObject> function1, final MessagePropertyMap propertyMap) {
        Intrinsics.checkNotNullParameter((Object)webviewMessageInterface, "webviewMessageInterface");
        Intrinsics.checkNotNullParameter((Object)propertyMap, "propertyMap");
        this.webviewMessageInterface = webviewMessageInterface;
        this.propertyMap = propertyMap;
        if (format == null) {
            final StringCompanionObject instance = StringCompanionObject.INSTANCE;
            format = String.format("%s.init", Arrays.copyOf(new Object[] { webviewMessageInterface.getInterfaceName() }, 1));
            Intrinsics.checkNotNullExpressionValue((Object)format, "java.lang.String.format(format, *args)");
        }
        this._initMessageName = format;
        final HashMap messageHandlers = new HashMap();
        this._messageHandlers = (HashMap<String, ValueCallback<JavascriptMessage>>)messageHandlers;
        this._callbackHandlers = (HashMap<String, Function1<JavascriptMessage, Unit>>)new HashMap();
        this._pendingMessages = (List<JavascriptMessage>)new ArrayList();
        webviewMessageInterface.setReceiver(this);
        ((Map)messageHandlers).put((Object)format, (Object)new ValueCallback<JavascriptMessage>(this, function1) {
            final Function1 $initMessageProcessor;
            final JavascriptBridge this$0;
            
            public final void onReceiveValue(final JavascriptMessage javascriptMessage) {
                JavascriptBridge.access$setInitialized$p(this.this$0, true);
                if (javascriptMessage.getCallback() == null) {
                    return;
                }
                final Function1 $initMessageProcessor = this.$initMessageProcessor;
                JSONObject jsonObject;
                if ($initMessageProcessor != null) {
                    Intrinsics.checkNotNullExpressionValue((Object)javascriptMessage, "it");
                    jsonObject = (JSONObject)$initMessageProcessor.invoke((Object)javascriptMessage);
                }
                else {
                    jsonObject = null;
                }
                final JavascriptMessage response = javascriptMessage.createResponse(jsonObject);
                try {
                    final Function1<JavascriptMessage, Unit> callback = javascriptMessage.getCallback();
                    if (callback != null) {
                        final Unit unit = (Unit)callback.invoke((Object)response);
                    }
                    this.this$0.flushPending();
                }
                catch (final Exception ex) {}
            }
        });
    }
    
    public static final /* synthetic */ void access$setInitialized$p(final JavascriptBridge javascriptBridge, final boolean initialized) {
        javascriptBridge.initialized = initialized;
    }
    
    private final void dispatchMessage(final JavascriptMessage javascriptMessage) {
        final Function1<JavascriptMessage, Unit> callback = javascriptMessage.getCallback();
        ++this.messageCount;
        final StringBuilder sb = new StringBuilder();
        sb.append(this.webviewMessageInterface.getInterfaceName());
        sb.append(")_");
        sb.append(this.messageCount);
        javascriptMessage.setId(sb.toString());
        if (callback != null) {
            final Map map = (Map)this._callbackHandlers;
            final String id = javascriptMessage.getId();
            Intrinsics.checkNotNull((Object)id);
            map.put((Object)id, (Object)callback);
        }
        final WebviewMessageInterface webviewMessageInterface = this.webviewMessageInterface;
        final String string = javascriptMessage.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, "message.toString()");
        webviewMessageInterface.dispatchMessage(string);
    }
    
    private final void flushPending() {
        final List<JavascriptMessage> pendingMessages = this._pendingMessages;
        if (pendingMessages != null && this.initialized) {
            Intrinsics.checkNotNull((Object)pendingMessages);
            final Iterator iterator = pendingMessages.iterator();
            while (iterator.hasNext()) {
                this.dispatchMessage((JavascriptMessage)iterator.next());
            }
        }
        final List list = null;
        this._pendingMessages = null;
    }
    
    private final void queueMessage(final JavascriptMessage javascriptMessage) {
        final List<JavascriptMessage> pendingMessages = this._pendingMessages;
        if (pendingMessages != null) {
            pendingMessages.add((Object)javascriptMessage);
        }
    }
    
    public final JavascriptMessage createMessage(final String name, final JSONObject payload, final Function1<? super JavascriptMessage, Unit> callback) {
        Intrinsics.checkNotNullParameter((Object)name, "name");
        final JavascriptMessage javascriptMessage = new JavascriptMessage(this.propertyMap);
        javascriptMessage.setName(name);
        javascriptMessage.setPayload(payload);
        if (callback != null) {
            javascriptMessage.setRsvp(true);
            javascriptMessage.setCallback(callback);
        }
        return javascriptMessage;
    }
    
    @Override
    public void didReceiveMessage(String responseTo) {
        Intrinsics.checkNotNullParameter((Object)responseTo, "json");
        try {
            final JavascriptMessage javascriptMessage = new JavascriptMessage(responseTo, this.propertyMap);
            if (javascriptMessage.getResponseTo() != null) {
                final Map map = (Map)this._callbackHandlers;
                responseTo = javascriptMessage.getResponseTo();
                if (map == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.collections.Map<K, *>");
                }
                if (map.containsKey((Object)responseTo)) {
                    final Function1 function1 = (Function1)((Map)this._callbackHandlers).get((Object)javascriptMessage.getResponseTo());
                    Intrinsics.checkNotNull((Object)function1);
                    function1.invoke((Object)javascriptMessage);
                    final Map map2 = (Map)this._callbackHandlers;
                    final String responseTo2 = javascriptMessage.getResponseTo();
                    if (map2 != null) {
                        TypeIntrinsics.asMutableMap((Object)map2).remove((Object)responseTo2);
                        return;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.collections.MutableMap<K, V>");
                }
            }
            if (this._messageHandlers.containsKey((Object)javascriptMessage.getName())) {
                final ValueCallback valueCallback = (ValueCallback)this._messageHandlers.get((Object)javascriptMessage.getName());
                if (javascriptMessage.getRsvp() && javascriptMessage.getId() != null) {
                    javascriptMessage.setCallback((Function1<? super JavascriptMessage, Unit>)new JavascriptBridge$didReceiveMessage.JavascriptBridge$didReceiveMessage$1(this, javascriptMessage));
                }
                Intrinsics.checkNotNull((Object)valueCallback);
                valueCallback.onReceiveValue((Object)javascriptMessage);
            }
        }
        catch (final Exception ex) {
            Log.e("JavascriptBridge", "JavascriptBridge didReceiveMessage failed.", (Throwable)ex);
        }
    }
    
    public final boolean getInitialized() {
        return this.initialized;
    }
    
    public final WebviewMessageInterface getWebviewMessageInterface() {
        return this.webviewMessageInterface;
    }
    
    public final void removeHandler(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "messageName");
        if ((Intrinsics.areEqual((Object)s, (Object)this._initMessageName) ^ true) && this._messageHandlers.containsKey((Object)s)) {
            this._messageHandlers.remove((Object)s);
        }
    }
    
    public final void sendMessage(final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)javascriptMessage, "message");
        if (!this.initialized) {
            this.queueMessage(javascriptMessage);
        }
        else {
            this.dispatchMessage(javascriptMessage);
        }
    }
    
    public final void sendMessage(final String s, final JSONObject jsonObject, final Function1<? super JavascriptMessage, Unit> function1) {
        Intrinsics.checkNotNullParameter((Object)s, "name");
        this.sendMessage(this.createMessage(s, jsonObject, function1));
    }
    
    public final void setHandler(final String s, final ValueCallback<JavascriptMessage> valueCallback) {
        Intrinsics.checkNotNullParameter((Object)s, "messageName");
        Intrinsics.checkNotNullParameter((Object)valueCallback, "handler");
        if (Intrinsics.areEqual((Object)s, (Object)this._initMessageName) ^ true) {
            ((Map)this._messageHandlers).put((Object)s, (Object)valueCallback);
        }
    }
}
