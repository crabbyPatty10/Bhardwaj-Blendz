package com.wearetrue.javascriptmessaging;

import org.json.JSONException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.Metadata;
import org.json.JSONObject;

@Metadata(bv = { 1, 0, 3 }, d1 = { "\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u0001B\u0007\b\u0016¢\u0006\u0002\u0010\u0002B\u0011\b\u0016\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005B\u0019\b\u0016\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\bJ\u0012\u0010+\u001a\u00020\u00002\n\b\u0002\u0010\u001d\u001a\u0004\u0018\u00010\u0001J\u001a\u0010,\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u00072\b\u0010-\u001a\u0004\u0018\u00010.H\u0002R\u001c\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000Rj\u0010\r\u001a%\u0012\u0013\u0012\u00110\u0000¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nj\u0004\u0018\u0001`\u00112)\u0010\r\u001a%\u0012\u0013\u0012\u00110\u0000¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nj\u0004\u0018\u0001`\u00118F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R(\u0010\u0016\u001a\u0004\u0018\u00010\u00072\b\u0010\u0016\u001a\u0004\u0018\u00010\u00078F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR$\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u000f\u001a\u00020\u00078F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u001b\u0010\u0018\"\u0004\b\u001c\u0010\u001aR(\u0010\u001d\u001a\u0004\u0018\u00010\u00012\b\u0010\u001d\u001a\u0004\u0018\u00010\u00018F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R(\u0010\"\u001a\u0004\u0018\u00010\u00072\b\u0010\"\u001a\u0004\u0018\u00010\u00078F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b#\u0010\u0018\"\u0004\b$\u0010\u001aR$\u0010%\u001a\u00020&2\u0006\u0010%\u001a\u00020&8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b'\u0010(\"\u0004\b)\u0010*¨\u0006/" }, d2 = { "Lcom/wearetrue/javascriptmessaging/JavascriptMessage;", "Lorg/json/JSONObject;", "()V", "propertyMap", "Lcom/wearetrue/javascriptmessaging/MessagePropertyMap;", "(Lcom/wearetrue/javascriptmessaging/MessagePropertyMap;)V", "json", "", "(Ljava/lang/String;Lcom/wearetrue/javascriptmessaging/MessagePropertyMap;)V", "_callbackHandler", "Lkotlin/Function1;", "", "_propertyMap", "callback", "Lkotlin/ParameterName;", "name", "message", "Lcom/wearetrue/javascriptmessaging/JavascriptMessageHandler;", "getCallback", "()Lkotlin/jvm/functions/Function1;", "setCallback", "(Lkotlin/jvm/functions/Function1;)V", "id", "getId", "()Ljava/lang/String;", "setId", "(Ljava/lang/String;)V", "getName", "setName", "payload", "getPayload", "()Lorg/json/JSONObject;", "setPayload", "(Lorg/json/JSONObject;)V", "responseTo", "getResponseTo", "setResponseTo", "rsvp", "", "getRsvp", "()Z", "setRsvp", "(Z)V", "createResponse", "setProperty", "value", "", "JavascriptMessaging_release" }, k = 1, mv = { 1, 4, 2 })
public final class JavascriptMessage extends JSONObject
{
    private Function1<? super JavascriptMessage, Unit> _callbackHandler;
    private final MessagePropertyMap _propertyMap;
    
    public JavascriptMessage() {
        this._propertyMap = new MessagePropertyMap();
    }
    
    public JavascriptMessage(final MessagePropertyMap propertyMap) {
        Intrinsics.checkNotNullParameter((Object)propertyMap, "propertyMap");
        this._propertyMap = propertyMap;
    }
    
    public JavascriptMessage(final String s, final MessagePropertyMap propertyMap) {
        Intrinsics.checkNotNullParameter((Object)s, "json");
        Intrinsics.checkNotNullParameter((Object)propertyMap, "propertyMap");
        super(s);
        this._propertyMap = propertyMap;
    }
    
    private final void setProperty(final String s, final Object o) {
        try {
            this.put(s, o);
        }
        catch (final JSONException ex) {}
    }
    
    public final JavascriptMessage createResponse(final JSONObject payload) {
        final JavascriptMessage javascriptMessage = new JavascriptMessage(this._propertyMap);
        javascriptMessage.setName(this.getName());
        javascriptMessage.setResponseTo(this.getId());
        javascriptMessage.setPayload(payload);
        return javascriptMessage;
    }
    
    public final Function1<JavascriptMessage, Unit> getCallback() {
        return (Function1<JavascriptMessage, Unit>)this._callbackHandler;
    }
    
    public final String getId() {
        return this.optString(this._propertyMap.getId());
    }
    
    public final String getName() {
        final String optString = this.optString(this._propertyMap.getName());
        Intrinsics.checkNotNullExpressionValue((Object)optString, "optString(_propertyMap.name)");
        return optString;
    }
    
    public final JSONObject getPayload() {
        return this.optJSONObject(this._propertyMap.getPayload());
    }
    
    public final String getResponseTo() {
        return this.optString(this._propertyMap.getResponseTo());
    }
    
    public final boolean getRsvp() {
        return this.optBoolean(this._propertyMap.getRsvp(), false);
    }
    
    public final void setCallback(final Function1<? super JavascriptMessage, Unit> callbackHandler) {
        this._callbackHandler = callbackHandler;
    }
    
    public final void setId(final String s) {
        this.setProperty(this._propertyMap.getId(), s);
    }
    
    public final void setName(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "name");
        this.setProperty(this._propertyMap.getName(), s);
    }
    
    public final void setPayload(final JSONObject jsonObject) {
        if (jsonObject != null) {
            this.setProperty(this._propertyMap.getPayload(), jsonObject);
        }
        else {
            this.remove(this._propertyMap.getPayload());
        }
    }
    
    public final void setResponseTo(final String s) {
        this.setProperty(this._propertyMap.getResponseTo(), s);
    }
    
    public final void setRsvp(final boolean b) {
        this.setProperty(this._propertyMap.getRsvp(), b);
    }
}
