package com.wearetrue.javascriptmessaging;

import kotlin.Metadata;

@Metadata(bv = { 1, 0, 3 }, d1 = { "\u0000\u0018\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000*@\u0010\u0000\"\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\u0004\u0012\u00020\u00060\u00012\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\u0004\u0012\u00020\u00060\u0001¨\u0006\u0007" }, d2 = { "JavascriptMessageHandler", "Lkotlin/Function1;", "Lcom/wearetrue/javascriptmessaging/JavascriptMessage;", "Lkotlin/ParameterName;", "name", "message", "", "JavascriptMessaging_release" }, k = 2, mv = { 1, 4, 2 })
public final class JavascriptMessageKt
{
}
