package com.wearetrue.javascriptmessaging;

import kotlin.jvm.internal.Intrinsics;
import kotlin.Metadata;

@Metadata(bv = { 1, 0, 3 }, d1 = { "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0016\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R$\u0010\t\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u00048F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR$\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u00048F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u000f\u0010\u000b\"\u0004\b\u0010\u0010\rR$\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u00048F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0012\u0010\u000b\"\u0004\b\u0013\u0010\rR$\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u00048F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0015\u0010\u000b\"\u0004\b\u0016\u0010\rR$\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0017\u001a\u00020\u00048F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0018\u0010\u000b\"\u0004\b\u0019\u0010\r¨\u0006\u001a" }, d2 = { "Lcom/wearetrue/javascriptmessaging/MessagePropertyMap;", "", "()V", "_id", "", "_name", "_payload", "_responseTo", "_rsvp", "id", "getId", "()Ljava/lang/String;", "setId", "(Ljava/lang/String;)V", "name", "getName", "setName", "payload", "getPayload", "setPayload", "responseTo", "getResponseTo", "setResponseTo", "rsvp", "getRsvp", "setRsvp", "JavascriptMessaging_release" }, k = 1, mv = { 1, 4, 2 })
public final class MessagePropertyMap
{
    private String _id;
    private String _name;
    private String _payload;
    private String _responseTo;
    private String _rsvp;
    
    public MessagePropertyMap() {
        this._id = "id";
        this._name = "name";
        this._payload = "payload";
        this._rsvp = "rsvp";
        this._responseTo = "responseTo";
    }
    
    public final String getId() {
        return this._id;
    }
    
    public final String getName() {
        return this._name;
    }
    
    public final String getPayload() {
        return this._payload;
    }
    
    public final String getResponseTo() {
        return this._responseTo;
    }
    
    public final String getRsvp() {
        return this._rsvp;
    }
    
    public final void setId(final String id) {
        Intrinsics.checkNotNullParameter((Object)id, "id");
        this._id = id;
    }
    
    public final void setName(final String name) {
        Intrinsics.checkNotNullParameter((Object)name, "name");
        this._name = name;
    }
    
    public final void setPayload(final String payload) {
        Intrinsics.checkNotNullParameter((Object)payload, "payload");
        this._payload = payload;
    }
    
    public final void setResponseTo(final String responseTo) {
        Intrinsics.checkNotNullParameter((Object)responseTo, "responseTo");
        this._responseTo = responseTo;
    }
    
    public final void setRsvp(final String rsvp) {
        Intrinsics.checkNotNullParameter((Object)rsvp, "rsvp");
        this._rsvp = rsvp;
    }
}
