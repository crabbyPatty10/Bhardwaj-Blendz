package com.wearetrue.playmakerx;

public final class BuildConfig
{
    public static final String APPLICATION_ID = "com.wearetrue.playmakerx.tackle";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "tackle";
    public static final int VERSION_CODE = 1005000;
    public static final String VERSION_NAME = "1.5.0";
}
