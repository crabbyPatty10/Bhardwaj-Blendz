package com.wearetrue.playmakerx;

import android.view.MotionEvent;
import android.view.View$OnTouchListener;
import android.webkit.WebChromeClient$FileChooserParams;
import android.webkit.WebChromeClient;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.widget.TextView;
import android.view.View$OnClickListener;
import android.widget.Button;
import android.view.animation.AnimationUtils;
import android.os.Bundle;
import android.content.res.Configuration;
import android.content.ClipData$Item;
import android.content.ClipData;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import android.content.pm.PackageManager$NameNotFoundException;
import android.net.NetworkCapabilities;
import android.net.ConnectivityManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes$Builder;
import android.print.PrintManager;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.os.VibrationEffect;
import android.os.Build$VERSION;
import android.os.Vibrator;
import org.json.JSONException;
import android.content.Intent;
import kotlin.text.StringsKt;
import android.app.Activity;
import kotlin.jvm.functions.Function1;
import com.wearetrue.javascriptmessaging.JavascriptMessageReceiver;
import com.wearetrue.javascriptmessaging.WebviewMessageInterface;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;
import com.wearetrue.javascriptmessaging.MessagePropertyMap;
import org.json.JSONObject;
import kotlin.jvm.internal.DefaultConstructorMarker;
import android.view.View;
import com.wearetrue.javascriptmessaging.JavascriptMessage;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.view.animation.Animation;
import com.wearetrue.javascriptmessaging.JavascriptBridge;
import kotlin.Metadata;
import androidx.appcompat.app.AppCompatActivity;

@Metadata(d1 = { "\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 :2\u00020\u0001:\u000389:B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0018\u001a\u00020\u0019H\u0002J\b\u0010\u001a\u001a\u00020\u0019H\u0002J\b\u0010\u001b\u001a\u00020\u0019H\u0002J\u0012\u0010\u001c\u001a\u00020\u00192\b\u0010\u001d\u001a\u0004\u0018\u00010\u0017H\u0002J\b\u0010\u001e\u001a\u00020\u0019H\u0002J\b\u0010\u001f\u001a\u00020\u000eH\u0002J\"\u0010 \u001a\u00020\u00192\u0006\u0010!\u001a\u00020\u00042\u0006\u0010\"\u001a\u00020\u00042\b\u0010#\u001a\u0004\u0018\u00010$H\u0014J\u0010\u0010%\u001a\u00020\u00192\u0006\u0010&\u001a\u00020'H\u0016J\u0012\u0010(\u001a\u00020\u00192\b\u0010)\u001a\u0004\u0018\u00010*H\u0014J\b\u0010+\u001a\u00020\u0019H\u0014J\b\u0010,\u001a\u00020\u0019H\u0014J\b\u0010-\u001a\u00020\u0019H\u0014J\b\u0010.\u001a\u00020\u0019H\u0014J\b\u0010/\u001a\u00020\u0019H\u0014J\b\u00100\u001a\u00020\u0019H\u0002J\u0010\u00101\u001a\u00020\u00192\u0006\u00102\u001a\u00020\u000eH\u0016J\u0010\u00103\u001a\u0002042\u0006\u00105\u001a\u000206H\u0002J\b\u00107\u001a\u00020\u0019H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006;" }, d2 = { "Lcom/wearetrue/playmakerx/MainActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "PERMISSIONS_PLAYMAKER", "", "bridge", "Lcom/wearetrue/javascriptmessaging/JavascriptBridge;", "fadeOut", "Landroid/view/animation/Animation;", "fileChooserCallback", "Landroid/webkit/ValueCallback;", "", "Landroid/net/Uri;", "isForgrounded", "", "loaded", "paymentManager", "Lcom/wearetrue/playmakerx/PaymentManager;", "retryView", "Landroid/widget/LinearLayout;", "spashImage", "Landroid/widget/ImageView;", "webView", "Landroid/webkit/WebView;", "configureBridge", "", "configureTroll", "configureWebview", "createWebPrintJob", "view", "hideSystemUI", "isIntenetAvailable", "onActivityResult", "requestCode", "resultCode", "intent", "Landroid/content/Intent;", "onConfigurationChanged", "config", "Landroid/content/res/Configuration;", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onPause", "onRestart", "onResume", "onStart", "onStop", "onWebviewLoadSuccess", "onWindowFocusChanged", "hasFocus", "processScriptInit", "Lorg/json/JSONObject;", "message", "Lcom/wearetrue/javascriptmessaging/JavascriptMessage;", "registerReceivers", "AppWebChromeClient", "AppWebTouchListener", "Companion", "app_tackleRelease" }, k = 1, mv = { 1, 8, 0 }, xi = 48)
public final class MainActivity extends AppCompatActivity
{
    public static final Companion Companion;
    private static final int IMAGECHOOSER_RESULTCODE = 1;
    private final int PERMISSIONS_PLAYMAKER;
    private JavascriptBridge bridge;
    private Animation fadeOut;
    private ValueCallback<Uri[]> fileChooserCallback;
    private boolean isForgrounded;
    private boolean loaded;
    private PaymentManager paymentManager;
    private LinearLayout retryView;
    private ImageView spashImage;
    private WebView webView;
    
    static {
        Companion = new Companion(null);
    }
    
    public MainActivity() {
        this.PERMISSIONS_PLAYMAKER = 1;
        this.paymentManager = new PaymentManager();
    }
    
    public static final /* synthetic */ void access$setFileChooserCallback$p(final MainActivity mainActivity, final ValueCallback fileChooserCallback) {
        mainActivity.fileChooserCallback = (ValueCallback<Uri[]>)fileChooserCallback;
    }
    
    private final void configureBridge() {
        final MessagePropertyMap messagePropertyMap = new MessagePropertyMap();
        final Context context = (Context)this;
        final WebView webView = this.webView;
        Intrinsics.checkNotNull((Object)webView);
        final WebviewMessageInterface webviewMessageInterface = new WebviewMessageInterface(context, webView, "nativeGateway", "ptnative", null, 16, null);
        messagePropertyMap.setName("type");
        (this.bridge = new JavascriptBridge(webviewMessageInterface, "webviewbridge.ready", (Function1<? super JavascriptMessage, ? extends JSONObject>)new MainActivity$configureBridge.MainActivity$configureBridge$1((Object)this), messagePropertyMap)).setHandler("app.print", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda4(this));
        final JavascriptBridge bridge = this.bridge;
        if (bridge != null) {
            bridge.setHandler("app.bootstrapped", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda9(this));
        }
        final JavascriptBridge bridge2 = this.bridge;
        if (bridge2 != null) {
            bridge2.setHandler("app.loadexternal", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda7(this));
        }
        final JavascriptBridge bridge3 = this.bridge;
        if (bridge3 != null) {
            bridge3.setHandler("app.vibrate", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda10(this));
        }
        final JavascriptBridge bridge4 = this.bridge;
        if (bridge4 != null) {
            bridge4.setHandler("app.iap.fetch", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda5(this));
        }
        final JavascriptBridge bridge5 = this.bridge;
        if (bridge5 != null) {
            bridge5.setHandler("app.iap.fetch.orphaned", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda6(this));
        }
        final JavascriptBridge bridge6 = this.bridge;
        if (bridge6 != null) {
            bridge6.setHandler("app.iap.purchase", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda11(this));
        }
        final JavascriptBridge bridge7 = this.bridge;
        if (bridge7 != null) {
            bridge7.setHandler("app.iap.finish", (ValueCallback<JavascriptMessage>)new MainActivity$$ExternalSyntheticLambda8(this));
        }
    }
    
    private static final void configureBridge$lambda$10(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        final PaymentManager paymentManager = mainActivity.paymentManager;
        Intrinsics.checkNotNullExpressionValue((Object)javascriptMessage, "it");
        paymentManager.handleMakePurchase(javascriptMessage, (Activity)mainActivity);
    }
    
    private static final void configureBridge$lambda$11(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        final PaymentManager paymentManager = mainActivity.paymentManager;
        Intrinsics.checkNotNullExpressionValue((Object)javascriptMessage, "it");
        paymentManager.handleFinishTransaction(javascriptMessage);
    }
    
    private static final void configureBridge$lambda$3(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        mainActivity.runOnUiThread((Runnable)new MainActivity$$ExternalSyntheticLambda2(mainActivity));
    }
    
    private static final void configureBridge$lambda$3$lambda$2(final MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        mainActivity.createWebPrintJob(mainActivity.webView);
    }
    
    private static final void configureBridge$lambda$5(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        mainActivity.runOnUiThread((Runnable)new MainActivity$$ExternalSyntheticLambda1(mainActivity));
    }
    
    private static final void configureBridge$lambda$5$lambda$4(final MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        mainActivity.onWebviewLoadSuccess();
    }
    
    private static final void configureBridge$lambda$6(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        try {
            final JSONObject payload = javascriptMessage.getPayload();
            Intrinsics.checkNotNull((Object)payload);
            final String string = payload.getString("url");
            Intrinsics.checkNotNullExpressionValue((Object)string, "url");
            String string2 = string;
            if (StringsKt.endsWith$default(string, ".pdf", false, 2, (Object)null)) {
                final StringBuilder sb = new StringBuilder();
                sb.append("https://docs.google.com/viewer?url=");
                sb.append(string);
                string2 = sb.toString();
            }
            final Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(string2));
            if (intent.resolveActivity(mainActivity.getPackageManager()) != null) {
                mainActivity.startActivity(intent);
            }
        }
        catch (final JSONException ex) {}
    }
    
    private static final void configureBridge$lambda$7(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        if (mainActivity.isForgrounded) {
            final Object systemService = mainActivity.getSystemService("vibrator");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.Vibrator");
            final Vibrator vibrator = (Vibrator)systemService;
            if (Build$VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(200L, -1));
            }
            else {
                vibrator.vibrate(200L);
            }
        }
    }
    
    private static final void configureBridge$lambda$8(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        final PaymentManager paymentManager = mainActivity.paymentManager;
        Intrinsics.checkNotNullExpressionValue((Object)javascriptMessage, "it");
        paymentManager.handleFetchProducts(javascriptMessage);
    }
    
    private static final void configureBridge$lambda$9(final MainActivity mainActivity, final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        final PaymentManager paymentManager = mainActivity.paymentManager;
        Intrinsics.checkNotNullExpressionValue((Object)javascriptMessage, "it");
        paymentManager.handleFetchOrphanedIaps(javascriptMessage);
    }
    
    private final void configureTroll() {
        this.paymentManager.start((Context)this);
    }
    
    private final void configureWebview() {
        final boolean equal = Intrinsics.areEqual((Object)this.getResources().getString(2131427377), (Object)"true");
        final WebView webView = this.webView;
        WebSettings settings;
        if (webView != null) {
            settings = webView.getSettings();
        }
        else {
            settings = null;
        }
        final WebView webView2 = this.webView;
        if (webView2 != null) {
            webView2.setBackgroundColor(this.getColor(2130968620));
        }
        if (settings != null) {
            settings.setCacheMode(-1);
        }
        if (settings != null) {
            settings.setLoadsImagesAutomatically(true);
        }
        if (settings != null) {
            settings.setJavaScriptEnabled(true);
        }
        if (settings != null) {
            settings.setDatabaseEnabled(true);
        }
        if (settings != null) {
            settings.setDomStorageEnabled(true);
        }
        if (settings != null) {
            settings.setAllowFileAccess(true);
        }
        if (settings != null) {
            settings.setGeolocationEnabled(true);
        }
        final WebView webView3 = this.webView;
        if (webView3 != null) {
            webView3.setOverScrollMode(2);
        }
        final WebView webView4 = this.webView;
        if (webView4 != null) {
            webView4.setVerticalScrollBarEnabled(false);
        }
        final WebView webView5 = this.webView;
        if (webView5 != null) {
            webView5.setHorizontalScrollBarEnabled(false);
        }
        if (equal) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        final WebView webView6 = this.webView;
        if (webView6 != null) {
            webView6.setWebViewClient((WebViewClient)new MainActivity$configureWebview.MainActivity$configureWebview$1(equal, this));
        }
    }
    
    private final void createWebPrintJob(final WebView webView) {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.getString(2131427367));
        sb.append(" Document");
        final String string = sb.toString();
        Intrinsics.checkNotNull((Object)webView);
        final PrintDocumentAdapter printDocumentAdapter = webView.createPrintDocumentAdapter(string);
        Intrinsics.checkNotNullExpressionValue((Object)printDocumentAdapter, "view!!.createPrintDocumentAdapter(jobName)");
        final Object systemService = this.getSystemService("print");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.print.PrintManager");
        ((PrintManager)systemService).print(string, printDocumentAdapter, new PrintAttributes$Builder().build());
    }
    
    private final void hideSystemUI() {
        final View decorView = this.getWindow().getDecorView();
        Intrinsics.checkNotNullExpressionValue((Object)decorView, "window.decorView");
        decorView.setSystemUiVisibility(2562);
    }
    
    private final boolean isIntenetAvailable() {
        final Object systemService = this.getSystemService("connectivity");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
        final ConnectivityManager connectivityManager = (ConnectivityManager)systemService;
        final NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
        return networkCapabilities != null && networkCapabilities.hasCapability(12);
    }
    
    private static final void onCreate$lambda$0(final MainActivity mainActivity, final View view) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        if (mainActivity.isIntenetAvailable() && !mainActivity.loaded) {
            final WebView webView = mainActivity.webView;
            if (webView != null) {
                webView.reload();
            }
            final ImageView spashImage = mainActivity.spashImage;
            if (spashImage != null) {
                spashImage.setAlpha(1.0f);
            }
            final LinearLayout retryView = mainActivity.retryView;
            if (retryView != null) {
                retryView.setAlpha(0.0f);
            }
        }
    }
    
    private static final void onCreate$lambda$1(final MainActivity mainActivity, final String s, final View view) {
        Intrinsics.checkNotNullParameter((Object)mainActivity, "this$0");
        Intrinsics.checkNotNullParameter((Object)s, "$supportAddress");
        if (!mainActivity.loaded) {
            final Intent intent = new Intent("android.intent.action.SENDTO");
            final StringBuilder sb = new StringBuilder();
            sb.append("mailto:");
            sb.append(s);
            intent.setData(Uri.parse(sb.toString()));
            intent.putExtra("android.intent.extra.EMAIL", new String[] { s });
            if (intent.resolveActivity(mainActivity.getPackageManager()) != null) {
                mainActivity.startActivity(intent);
            }
        }
    }
    
    private final void onWebviewLoadSuccess() {
        if (!this.loaded) {
            this.loaded = true;
            final ImageView spashImage = this.spashImage;
            Intrinsics.checkNotNull((Object)spashImage);
            spashImage.startAnimation(this.fadeOut);
            final WebView webView = this.webView;
            if (webView != null) {
                webView.setAlpha(1.0f);
            }
            final LinearLayout retryView = this.retryView;
            if (retryView != null) {
                retryView.setAlpha(0.0f);
            }
            final WebView webView2 = this.webView;
            if (webView2 != null) {
                webView2.bringToFront();
            }
        }
    }
    
    private final JSONObject processScriptInit(final JavascriptMessage javascriptMessage) {
        final JSONObject jsonObject = new JSONObject();
        String versionName;
        try {
            versionName = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
            Intrinsics.checkNotNullExpressionValue((Object)versionName, "packageManager.getPackag\u2026ckageName, 0).versionName");
        }
        catch (final PackageManager$NameNotFoundException ex) {
            versionName = "";
        }
        jsonObject.put("version", (Object)versionName);
        jsonObject.put("os", (Object)"android");
        jsonObject.put("supportsIap", true);
        return jsonObject;
    }
    
    private final void registerReceivers() {
    }
    
    protected void onActivityResult(int i, int itemCount, final Intent intent) {
        if (i == 1) {
            final List list = (List)new ArrayList();
            Object o = null;
            Label_0171: {
                if (itemCount == -1) {
                    if (intent != null) {
                        try {
                            final String dataString = intent.getDataString();
                            final ClipData clipData = intent.getClipData();
                            if (clipData != null) {
                                ClipData$Item item;
                                Uri uri;
                                for (itemCount = clipData.getItemCount(), i = 0; i < itemCount; ++i) {
                                    item = clipData.getItemAt(i);
                                    if (item != null) {
                                        uri = item.getUri();
                                        Intrinsics.checkNotNullExpressionValue((Object)uri, "item.uri");
                                        list.add((Object)uri);
                                    }
                                }
                            }
                            o = list;
                            if (dataString == null) {
                                break Label_0171;
                            }
                            final Uri parse = Uri.parse(dataString);
                            i = 0;
                            while (true) {
                                o = list;
                                if (i >= 1) {
                                    break Label_0171;
                                }
                                final Uri uri2 = (new Uri[] { parse })[i];
                                Intrinsics.checkNotNullExpressionValue((Object)uri2, "uri");
                                list.add((Object)uri2);
                                ++i;
                            }
                        }
                        catch (final Exception ex) {
                            ex.printStackTrace();
                            o = list;
                            break Label_0171;
                        }
                    }
                }
                o = null;
            }
            if (o != null && ((List)o).size() > 0) {
                final ValueCallback<Uri[]> fileChooserCallback = this.fileChooserCallback;
                if (fileChooserCallback != null) {
                    Intrinsics.checkNotNull((Object)fileChooserCallback);
                    fileChooserCallback.onReceiveValue((Object)((Collection)o).toArray((Object[])new Uri[0]));
                    this.fileChooserCallback = null;
                }
            }
        }
    }
    
    public void onConfigurationChanged(final Configuration configuration) {
        Intrinsics.checkNotNullParameter((Object)configuration, "config");
        super.onConfigurationChanged(configuration);
        if (configuration.orientation == 2) {
            this.getWindow().addFlags(1024);
        }
        else {
            this.getWindow().clearFlags(1024);
        }
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        final String string = this.getResources().getString(2131427380);
        Intrinsics.checkNotNullExpressionValue((Object)string, "resources.getString(R.string.support_address)");
        final String string2 = this.getResources().getString(2131427368);
        Intrinsics.checkNotNullExpressionValue((Object)string2, "resources.getString(R.string.app_url)");
        this.loaded = false;
        this.setContentView(2131296284);
        this.fadeOut = AnimationUtils.loadAnimation((Context)this, 2130771980);
        this.webView = (WebView)this.findViewById(2131165380);
        this.spashImage = (ImageView)this.findViewById(2131165378);
        this.retryView = (LinearLayout)this.findViewById(2131165377);
        final View viewById = this.findViewById(2131165252);
        Intrinsics.checkNotNullExpressionValue((Object)viewById, "findViewById(R.id.button_retry)");
        ((Button)viewById).setOnClickListener((View$OnClickListener)new MainActivity$$ExternalSyntheticLambda0(this));
        final View viewById2 = this.findViewById(2131165376);
        Intrinsics.checkNotNullExpressionValue((Object)viewById2, "findViewById(R.id.view_contact_support)");
        ((TextView)viewById2).setOnClickListener((View$OnClickListener)new MainActivity$$ExternalSyntheticLambda3(this, string));
        if (Build$VERSION.SDK_INT >= 24) {
            final ServiceWorkerController instance = ServiceWorkerController.getInstance();
            Intrinsics.checkNotNullExpressionValue((Object)instance, "getInstance()");
            instance.setServiceWorkerClient((ServiceWorkerClient)new MainActivity$onCreate.MainActivity$onCreate$3(this));
        }
        this.configureTroll();
        this.configureWebview();
        this.configureBridge();
        final WebView webView = this.webView;
        if (webView != null) {
            webView.setWebChromeClient((WebChromeClient)new AppWebChromeClient());
        }
        final WebView webView2 = this.webView;
        if (webView2 != null) {
            webView2.loadUrl(string2);
        }
    }
    
    protected void onPause() {
        super.onPause();
        this.isForgrounded = false;
    }
    
    protected void onRestart() {
        super.onRestart();
        this.hideSystemUI();
        this.registerReceivers();
    }
    
    protected void onResume() {
        super.onResume();
        this.isForgrounded = true;
    }
    
    protected void onStart() {
        super.onStart();
        this.hideSystemUI();
        this.registerReceivers();
    }
    
    protected void onStop() {
        super.onStop();
    }
    
    public void onWindowFocusChanged(final boolean b) {
        super.onWindowFocusChanged(b);
        if (b) {
            this.hideSystemUI();
        }
    }
    
    @Metadata(d1 = { "\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0080\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J,\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0012\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b2\u0006\u0010\u000b\u001a\u00020\fH\u0016¨\u0006\r" }, d2 = { "Lcom/wearetrue/playmakerx/MainActivity$AppWebChromeClient;", "Landroid/webkit/WebChromeClient;", "(Lcom/wearetrue/playmakerx/MainActivity;)V", "onShowFileChooser", "", "mWebView", "Landroid/webkit/WebView;", "callback", "Landroid/webkit/ValueCallback;", "", "Landroid/net/Uri;", "fileChooserParams", "Landroid/webkit/WebChromeClient$FileChooserParams;", "app_tackleRelease" }, k = 1, mv = { 1, 8, 0 }, xi = 48)
    public final class AppWebChromeClient extends WebChromeClient
    {
        final MainActivity this$0;
        
        public AppWebChromeClient(final MainActivity this$0) {
            this.this$0 = this$0;
        }
        
        public boolean onShowFileChooser(final WebView webView, final ValueCallback<Uri[]> valueCallback, final WebChromeClient$FileChooserParams webChromeClient$FileChooserParams) {
            Intrinsics.checkNotNullParameter((Object)webView, "mWebView");
            Intrinsics.checkNotNullParameter((Object)valueCallback, "callback");
            Intrinsics.checkNotNullParameter((Object)webChromeClient$FileChooserParams, "fileChooserParams");
            MainActivity.access$setFileChooserCallback$p(this.this$0, valueCallback);
            final Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            if (intent.resolveActivity(this.this$0.getPackageManager()) != null) {
                this.this$0.startActivityForResult(intent, 1);
            }
            return true;
        }
    }
    
    @Metadata(d1 = { "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0080\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0016¨\u0006\t" }, d2 = { "Lcom/wearetrue/playmakerx/MainActivity$AppWebTouchListener;", "Landroid/view/View$OnTouchListener;", "(Lcom/wearetrue/playmakerx/MainActivity;)V", "onTouch", "", "view", "Landroid/view/View;", "motionEvent", "Landroid/view/MotionEvent;", "app_tackleRelease" }, k = 1, mv = { 1, 8, 0 }, xi = 48)
    public final class AppWebTouchListener implements View$OnTouchListener
    {
        final MainActivity this$0;
        
        public AppWebTouchListener(final MainActivity this$0) {
            this.this$0 = this$0;
        }
        
        public boolean onTouch(final View view, final MotionEvent motionEvent) {
            Intrinsics.checkNotNullParameter((Object)view, "view");
            Intrinsics.checkNotNullParameter((Object)motionEvent, "motionEvent");
            return motionEvent.getAction() == 2;
        }
    }
    
    @Metadata(d1 = { "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0005" }, d2 = { "Lcom/wearetrue/playmakerx/MainActivity$Companion;", "", "()V", "IMAGECHOOSER_RESULTCODE", "", "app_tackleRelease" }, k = 1, mv = { 1, 8, 0 }, xi = 48)
    public static final class Companion
    {
        private Companion() {
        }
    }
}
