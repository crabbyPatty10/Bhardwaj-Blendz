package com.wearetrue.playmakerx;

import android.content.Context;
import android.app.Activity;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.BuildersKt;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function2;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import com.android.billingclient.api.AccountIdentifiers;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;
import com.android.billingclient.api.Purchase;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.JobKt;
import com.android.billingclient.api.BillingResult;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.CoroutineScope;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.ProductDetails;
import java.util.List;
import com.wearetrue.javascriptmessaging.JavascriptMessage;
import com.android.billingclient.api.BillingClient;
import kotlin.Metadata;

@Metadata(d1 = { "\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0006J\u000e\u0010\u0013\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0006J\u000e\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0006J\u0016\u0010\u0015\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\u0017J\u0018\u0010\u0018\u001a\u00020\u00112\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u0006H\u0002J)\u0010\u001c\u001a\u00020\u00112!\u0010\u001d\u001a\u001d\u0012\u0013\u0012\u00110\u001f¢\u0006\f\b \u0012\b\b!\u0012\u0004\b\b(\"\u0012\u0004\u0012\u00020\u00110\u001eJ\u000e\u0010#\u001a\u00020\u00112\u0006\u0010$\u001a\u00020%R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082.¢\u0006\u0002\n\u0000¨\u0006&" }, d2 = { "Lcom/wearetrue/playmakerx/PaymentManager;", "", "()V", "billingClient", "Lcom/android/billingclient/api/BillingClient;", "pendingPurchaseMessage", "Lcom/wearetrue/javascriptmessaging/JavascriptMessage;", "productDetails", "", "Lcom/android/billingclient/api/ProductDetails;", "purchasesUpdatedListener", "Lcom/android/billingclient/api/PurchasesUpdatedListener;", "scope", "Lkotlinx/coroutines/CoroutineScope;", "setupJob", "Lkotlinx/coroutines/Job;", "handleFetchOrphanedIaps", "", "message", "handleFetchProducts", "handleFinishTransaction", "handleMakePurchase", "activity", "Landroid/app/Activity;", "processPurchase", "purchase", "Lcom/android/billingclient/api/Purchase;", "purchaseMessage", "queryPurchasesAsync", "processResults", "Lkotlin/Function1;", "Lorg/json/JSONObject;", "Lkotlin/ParameterName;", "name", "payload", "start", "context", "Landroid/content/Context;", "app_tackleRelease" }, k = 1, mv = { 1, 8, 0 }, xi = 48)
public final class PaymentManager
{
    private BillingClient billingClient;
    private JavascriptMessage pendingPurchaseMessage;
    private List<ProductDetails> productDetails;
    private final PurchasesUpdatedListener purchasesUpdatedListener;
    private final CoroutineScope scope;
    private Job setupJob;
    
    public PaymentManager() {
        this.scope = CoroutineScopeKt.CoroutineScope(JobKt.Job$default((Job)null, 1, (Object)null).plus((CoroutineContext)Dispatchers.getIO()));
        this.purchasesUpdatedListener = (PurchasesUpdatedListener)new PaymentManager$$ExternalSyntheticLambda0(this);
    }
    
    private final void processPurchase(final Purchase purchase, final JavascriptMessage javascriptMessage) {
        final JSONObject payload = javascriptMessage.getPayload();
        Object obfuscatedAccountId = null;
        String string;
        if (payload != null) {
            string = payload.getString("productId");
        }
        else {
            string = null;
        }
        final String s = (String)purchase.getSkus().get(0);
        final AccountIdentifiers accountIdentifiers = purchase.getAccountIdentifiers();
        if (accountIdentifiers != null) {
            obfuscatedAccountId = accountIdentifiers.getObfuscatedAccountId();
        }
        final JSONObject jsonObject = new JSONObject();
        if (!Intrinsics.areEqual((Object)s, (Object)string)) {
            jsonObject.put("error", (Object)"Invalid SKU");
        }
        else if (purchase.isAcknowledged()) {
            jsonObject.put("error", (Object)"Purchase has already been acknowledged");
        }
        else if (purchase.getPurchaseState() != 1) {
            jsonObject.put("error", (Object)"Purchase is pending or canceled");
        }
        else {
            jsonObject.put("orderId", (Object)purchase.getOrderId());
            jsonObject.put("transactionId", (Object)purchase.getPurchaseToken());
            jsonObject.put("productId", (Object)string);
            jsonObject.put("teamId", obfuscatedAccountId);
        }
        final Function1<JavascriptMessage, Unit> callback = javascriptMessage.getCallback();
        if (callback != null) {
            callback.invoke((Object)javascriptMessage.createResponse(jsonObject));
        }
    }
    
    private static final void purchasesUpdatedListener$lambda$0(final PaymentManager paymentManager, final BillingResult billingResult, final List list) {
        Intrinsics.checkNotNullParameter((Object)paymentManager, "this$0");
        Intrinsics.checkNotNullParameter((Object)billingResult, "billingResult");
        final JavascriptMessage pendingPurchaseMessage = paymentManager.pendingPurchaseMessage;
        if (pendingPurchaseMessage != null) {
            paymentManager.pendingPurchaseMessage = null;
            if (billingResult.getResponseCode() == 0 && list != null) {
                final Object value = list.get(0);
                Intrinsics.checkNotNullExpressionValue(value, "purchases[0]");
                paymentManager.processPurchase((Purchase)value, pendingPurchaseMessage);
            }
            else {
                final JSONObject jsonObject = new JSONObject();
                String s;
                if (billingResult.getResponseCode() == 1) {
                    s = "Purchase canceled";
                }
                else {
                    s = "Purchase failed";
                }
                jsonObject.put("error", (Object)s);
                final Function1<JavascriptMessage, Unit> callback = pendingPurchaseMessage.getCallback();
                if (callback != null) {
                    callback.invoke((Object)pendingPurchaseMessage.createResponse(jsonObject));
                }
            }
        }
    }
    
    public final void handleFetchOrphanedIaps(final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)javascriptMessage, "message");
        BuildersKt.launch$default(this.scope, (CoroutineContext)null, (CoroutineStart)null, (Function2)new PaymentManager$handleFetchOrphanedIaps.PaymentManager$handleFetchOrphanedIaps$1(this, javascriptMessage, (Continuation)null), 3, (Object)null);
    }
    
    public final void handleFetchProducts(final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)javascriptMessage, "message");
        BuildersKt.launch$default(this.scope, (CoroutineContext)null, (CoroutineStart)null, (Function2)new PaymentManager$handleFetchProducts.PaymentManager$handleFetchProducts$1(javascriptMessage, this, (Continuation)null), 3, (Object)null);
    }
    
    public final void handleFinishTransaction(final JavascriptMessage javascriptMessage) {
        Intrinsics.checkNotNullParameter((Object)javascriptMessage, "message");
        BuildersKt.launch$default(this.scope, (CoroutineContext)null, (CoroutineStart)null, (Function2)new PaymentManager$handleFinishTransaction.PaymentManager$handleFinishTransaction$1(javascriptMessage, this, (Continuation)null), 3, (Object)null);
    }
    
    public final void handleMakePurchase(final JavascriptMessage pendingPurchaseMessage, final Activity activity) {
        Intrinsics.checkNotNullParameter((Object)pendingPurchaseMessage, "message");
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        if (this.pendingPurchaseMessage == null) {
            this.pendingPurchaseMessage = pendingPurchaseMessage;
            BuildersKt.launch$default(this.scope, (CoroutineContext)null, (CoroutineStart)null, (Function2)new PaymentManager$handleMakePurchase.PaymentManager$handleMakePurchase$1(pendingPurchaseMessage, this, activity, (Continuation)null), 3, (Object)null);
        }
    }
    
    public final void queryPurchasesAsync(final Function1<? super JSONObject, Unit> function1) {
        Intrinsics.checkNotNullParameter((Object)function1, "processResults");
        BuildersKt.launch$default(this.scope, (CoroutineContext)null, (CoroutineStart)null, (Function2)new PaymentManager$queryPurchasesAsync.PaymentManager$queryPurchasesAsync$1(this, (Function1)function1, (Continuation)null), 3, (Object)null);
    }
    
    public final void start(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        this.billingClient = BillingClient.newBuilder(context).setListener(this.purchasesUpdatedListener).enablePendingPurchases().build();
        this.setupJob = BuildersKt.launch$default(this.scope, (CoroutineContext)null, (CoroutineStart)null, (Function2)new PaymentManager$start.PaymentManager$start$1(this, (Continuation)null), 3, (Object)null);
    }
}
